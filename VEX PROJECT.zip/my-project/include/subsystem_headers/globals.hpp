#include "main.h"

// motors
// extern symbolizes external and allows you to define the same thing in mutliple files without causing a name error
extern pros::Motor lift;
extern pros::Motor angler;
extern pros::Motor intake_left;
extern pros::Motor intake_right;
extern pros::Motor drive_left_back;
extern pros::Motor drive_left_front;
extern pros::Motor drive_right_back;
extern pros::Motor drive_right_front;

// controller
extern pros::Controller controller;

// miscellaneous 
extern pros::ADIGyro gryro;