#include "main.h"
//helper func

void setAngler(int power);

// angler motor

void setAnglerMotor();