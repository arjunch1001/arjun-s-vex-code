#include "main.h"


//helper func

void setLift(int power) {
    lift = power;
}

// lift motor

void setLiftMotor () {
    int lift_power = 127 * (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2) - controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1));
    // bottom trigger makes it go down and top trigger makes it go up
     setLift(lift_power);
}
    