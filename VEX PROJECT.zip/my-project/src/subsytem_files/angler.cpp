#include "main.h"
pros::ADIPotentiometer anglerPot('A');
//helper func

void setAngler(int power) {
    angler = power;
}

// intake motor

void setAnglerMotor () {
    int angler_power = 127 * (controller.get_digital(pros::E_CONTROLLER_DIGITAL_UP) - controller.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN));
    // Up makes the angler go up and down makes the angler go down
    
     setAngler(angler_power);
}
