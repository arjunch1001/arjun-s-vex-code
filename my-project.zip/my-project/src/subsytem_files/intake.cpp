#include "main.h"

//helper func

void setIntake(int power) {
    intake_left = power;
    intake_right = power;
}

// intake motor

void setIntakeMotor () {
    int intake_power = 127 * (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L1) - controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2));
    // bottom trigger intakes and upper trigger outtakes 
    
     setIntake(intake_power);
}
