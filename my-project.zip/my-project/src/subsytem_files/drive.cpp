#include "main.h"

// gyroscope helps acocunt for uneven rpm between different drive motors
// define a sensor scale to match value types 
// 0.91 is the sensor scale factor
pros::ADIGyro gyro('B', 0.91);


//helper functions
void setDrive (int left, int right) {
    drive_left_back = left;
    drive_left_front = left;
    drive_right_back = right;
    drive_right_front = right;
}

//resets all values of the drive to 0
void resetMotorEncoder() {
    drive_left_back.tare_position();
    drive_left_front.tare_position();
    drive_right_back.tare_position();
    drive_right_front.tare_position();
}

// returns the average position of all four encoders for precision
double avgDriveEncoderValue() {
    return (fabs(drive_left_back.get_position()) +
          fabs(drive_left_front.get_position()) +
          fabs(drive_right_back.get_position()) +
          fabs(drive_right_front.get_position())) / 4;

}


// driver control fucntions 
void setDriveMotors () {
    int left_joystick = controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
    int right_joystick = controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_Y);
    if (abs(left_joystick) < 10) left_joystick = 0;
    if (abs(right_joystick) < 10) right_joystick = 0;
    setDrive(left_joystick, right_joystick);
}


// AUTONOMOUS FUNCTIONS
void translate(int units, int voltage) {
    int direction = abs(units) / units;
    //reset motor encoder and gyro
    resetMotorEncoder();
    gyro.reset();
    //drive forward until units are reached, 
    while (avgDriveEncoderValue() < abs(units)) 
        setDrive(voltage * direction + gyro.get_value(), voltage * direction - gyro.get_value()); 
    //breif brake to cancel momentum and stop quickly 
    setDrive(-10 * direction, -10 * direction);
    pros::delay(50);
    // set drive to neutral 
    setDrive(0, 0); 

}


void rotate(int degrees, int voltage) {
    // define direcvtion , based on units provided
    int direction = abs(degrees)/degrees;
    // reset gyroscope 
    gyro.reset();
    // turn until units are reached
    setDrive(-voltage*direction, voltage * direction);
    while (fabs(gyro.get_value()) < abs(degrees * 10) - 50) {
        pros::delay(10);
    }
    pros::delay(100);
    if (fabs(gyro.get_value()) > degrees * 10) {
        setDrive(0.5 * voltage *direction, 0.5 * -voltage * direction);
        while (fabs(gyro.get_value()) > abs(degrees * 10)) {
        pros::delay(10);
        }   
    }
    else if (fabs(gyro.get_value()) < abs(degrees * 10)) {
        setDrive(0.5 * -voltage *direction, 0.5 * voltage * direction);
        while (fabs(gyro.get_value()) > abs(degrees * 10)) {
        pros::delay(10);
        }   
    }

    
    // brief brake
    setDrive(voltage*direction, -voltage*direction);
    // reset drive to zero
    setDrive(0,0);
}