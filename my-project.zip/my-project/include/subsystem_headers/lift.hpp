#include "main.h"

//helper func

void setLift(int power);
// lift motor

void setLiftMotor ();
