#include "main.h"

void setDrive(int left, int right);

// driver control functions

void setDriveMotors();

//AUTONOMOUS FUNCTIONS

void translate(int units, int voltage);

double avgDriveEncoderValue();

void rotate(int degrees, int voltage);