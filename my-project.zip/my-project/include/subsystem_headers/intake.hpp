#include "main.h"

void setIntake(int power); 

void setIntakeMotor();
